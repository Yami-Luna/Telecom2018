#include <click/config.h>
#include <click/confparse.hh>
#include <click/error.hh>
#include <click/handler.hh>
#include <click/handlercall.hh>
#include <click/ipaddress.hh>
#include <clicknet/ip.h>
#include <clicknet/icmp.h>
#include <clicknet/udp.h>
#include <arpa/inet.h>
#include <string.h>
#include "advertisement.hh"
#include "registrationRequest.hh"
#include "registrationReply.hh"
#include "ipHeader.hh"

CLICK_DECLS

void doRegister(Timer * timer, void * data)
{
	((RegistrationRequest *) data)->reRegister();
}

RegistrationRequest::RegistrationRequest() : counter(0), _currentAgent(0), timer(this), _lastP(0), _rr(0), _registrated(false), reregister(doRegister, (void *) this), _lastRequest(0), _sol(0), _lastSequenceNumber(-1) {}

RegistrationRequest::~RegistrationRequest() {}

int RegistrationRequest::configure(Vector<String> &conf, ErrorHandler *errh) {
	if (cp_va_kparse(conf, this, errh,	"ISMOBILENODE", cpkM, cpBool, &isMobileNode,
										"GATEWAY", cpkM, cpIPAddress, &_gateway,
										"ME", cpkM, cpIPAddress, &_me,
										"SOLICITATION", cpkN, cpElement, &_sol,
										"LIFETIME", cpkM, cpInteger, &_lifetime,
										"REPLIER", cpkN, cpElement, &_rr,
										cpEnd) < 0) return -1;

	if (isMobileNode)
	{
		timer.initialize(this);
		timer.schedule_after_msec(0);

		reregister.initialize(this);
	}

	return 0;
}

void RegistrationRequest::forward(Packet * p)
{
	click_icmp_echo * icmp_h = (click_icmp_echo *) (p->data() + sizeof(click_ip));
	click_udp * udph = (click_udp *) (p->data() + sizeof(click_ip));
	click_ip *oldip = (click_ip *) p->ip_header();

	int offset = 0;
	int tailroom = 0;
	int headroom = sizeof(click_ip);
	int packetsize = headroom + sizeof(click_udp);
	oldip->ip_sum = 0;
	if (p->ip_header()->ip_sum != click_in_cksum((const unsigned char *) oldip, sizeof(click_ip))) {
		packetsize += sizeof(RegistrationReplyData);
	} else {
		packetsize += sizeof(RegistrationRequestData);
	}
	WritablePacket * packet = Packet::make(headroom, 0, packetsize, tailroom);

	if (packet == 0) {
		click_chatter( "Cannot make packet");

		p->kill();

		return;
	}

	memset(packet->data(), 0, packetsize);
	memcpy(packet->data(), p->data(), packetsize);

	RegistrationRequestData *oldrrq = (RegistrationRequestData *) (p->data() + sizeof(click_ip) + sizeof(click_udp));

	click_ip * ip = (click_ip *) packet->data();
	click_udp * oldudp = (click_udp *) (p->data() + sizeof(click_ip));

	int oldsum = oldudp->uh_sum;
	oldudp->uh_sum = 0;
	if ((oldsum != 0) && (oldsum != click_in_cksum((const unsigned char *) oldudp, sizeof(click_udp) + sizeof(RegistrationRequestData)))) {
		click_chatter("Foreign Agent -- Silently discard registration request, invalid, non-zero udp checksum.");
		return;
	} else if ((oldrrq->flags & (0x1 << 1)) || (oldrrq->flags & 0x1)) {
		click_chatter("Foreign Agent -- Sending error 70 in registration reply.");

		ip->ip_src = p->ip_header()->ip_dst;
		ip->ip_dst = p->ip_header()->ip_src;
		checksumIPHeader(ip);
		packet->set_dst_ip_anno(ip->ip_dst);

		click_udp * udp = (click_udp *) (packet->data() + sizeof(click_ip));
		udp->uh_sport = oldudp->uh_sport;
		udp->uh_dport = oldudp->uh_dport;
		udp->uh_ulen = htons(sizeof(click_udp) + sizeof(RegistrationReplyData));
		packet->set_network_header((unsigned char *) ip, sizeof(click_ip) + sizeof(click_udp));

		RegistrationReplyData * rr = (RegistrationReplyData *) (packet->data() + sizeof(click_ip) + sizeof(click_udp));
		rr->type = oldrrq->type;
		rr->code = 70;
		rr->lifetime = 0xffff;
		rr->homeAddress = oldrrq->homeAddress;
		rr->homeAgent = oldrrq->homeAgent;
		rr->identification = oldrrq->identification;
		HandlerCall::call_write("storeIdentification", String(rr->identification), (Element *) _rr, new ErrorHandler());
		udp->uh_sum = 0;
		udp->uh_sum = click_in_cksum((const unsigned char *) udp, sizeof(click_udp) + sizeof(RegistrationReplyData));

		output(0).push(packet);
		p->kill();
		return;
	}

	click_chatter("Foreign Agent -- Forwarding registration request.");

	RegistrationRequestData *rrq = (RegistrationRequestData *) (packet->data() + sizeof(click_ip) + sizeof(click_udp));
	ip->ip_src = _gateway;
	ip->ip_dst = oldrrq->homeAgent; // forward to home agent
	checksumIPHeader(ip);
	packet->set_dst_ip_anno(ip->ip_dst);
	rrq->careOfAddress = _gateway;

	if (ntohs(rrq->lifetime) > _lifetime)
		rrq->lifetime = htons(_lifetime);

	click_udp * udp = (click_udp *) (packet->data() + sizeof(click_ip));
	packet->set_network_header((unsigned char *) ip, sizeof(click_ip) + sizeof(click_udp));
	udp->uh_sum = 0;
	udp->uh_sum = click_in_cksum((const unsigned char *) udp, sizeof(click_udp) + sizeof(RegistrationReplyData));

	output(0).push(packet);
}

bool is_bit_set(unsigned value, unsigned bitindex)
{
    return (value & (1 << bitindex)) != 0;
}

void RegistrationRequest::generateRequest(Packet * p)
{
	if (time(0) == _lastRequest)
	{
		reregister.clear();
		reregister.schedule_after_msec(1000);

		return;
	}

	click_icmp_echo * icmp_h = (click_icmp_echo *) (p->data() + sizeof(click_ip));
	click_udp * udph = (click_udp *) (p->data() + sizeof(click_ip));
	click_ip *oldip = (click_ip *) p->ip_header();

	bool isHomeAgent = IPAddress(oldip->ip_src).matches_prefix(_me, IPAddress::make_prefix(24));

	if (isHomeAgent)
	{
		click_chatter("Mobile Node -- Sending deregistration to home agent.");

		reregister.clear();
	}
	else
	{
		click_chatter("Mobile Node -- Sending registration to foreign agent.");

		reregister.clear();
		reregister.schedule_after_msec(_lifetime * 1000 - 500);
	}

	MobileAgentAdvertisement * maa = (MobileAgentAdvertisement *) (p->data() + sizeof(click_ip) + sizeof(click_icmp_echo) / 2 + sizeof(ICMPRouterAdvertisement));

	if (!isHomeAgent && !is_bit_set(maa->flags, 7)) {
		click_chatter("Mobile Node -- The foreign agent I'm connected with does not seem to support registration.");
	} else if (p->length() > sizeof(click_ip) + sizeof(click_icmp_echo)) {
		int offset = 0;
		int tailroom = 0;
		int headroom = sizeof(click_ip);
		int packetsize = headroom + sizeof(click_udp) + sizeof(RegistrationRequestData);
		WritablePacket * packet = Packet::make(headroom, 0, packetsize, tailroom);

		if (packet == 0) {
			click_chatter( "Cannot make packet");
			p->kill();
			return;
		}

		ICMPRouterAdvertisement * ira = (ICMPRouterAdvertisement *) (packet->data() + sizeof(click_ip) + sizeof(click_icmp_echo) / 2);
		int lifetime = ira->lifetime;
		// TODO read and delete from list
		if (agents.find(oldip->ip_dst) != agents.end()) {
			agents.insert(std::pair<struct in_addr, int>(oldip->ip_dst, lifetime));
		} else {
			agents.find(oldip->ip_dst)->second = lifetime;
		}

		memset(packet->data(), 0, packetsize);

		click_ip * ip = initIPHeader(packet, (click_ip *) (packet->data() + offset), packetsize, 17, counter, 128, _me, oldip->ip_src);
		offset += sizeof(click_ip);

		click_udp * udp = (click_udp *) (packet->data() + offset);
		udp->uh_sport = htons(1337);
		udp->uh_dport = htons(434);
		udp->uh_ulen = htons(sizeof(click_udp) + sizeof(RegistrationRequestData));
		offset += sizeof(click_udp);
		packet->set_network_header((unsigned char *) ip, sizeof(click_ip) + sizeof(click_udp));

		RegistrationRequestData *rr = (RegistrationRequestData *) (packet->data() + offset);
		rr->type = 1;
		rr->flags = 1 << 6;

		if (isHomeAgent)
			rr->lifetime = 0;
		else
			rr->lifetime = htons(_lifetime);

		rr->homeAddress = oldip->ip_dst;
		rr->homeAgent = _gateway;
		memcpy(&rr->careOfAddress, (IPAddress *) (p->data() + sizeof(click_ip) + sizeof(click_icmp_echo) / 2 + sizeof(ICMPRouterAdvertisement) + sizeof(MobileAgentAdvertisement)), sizeof(IPAddress));
		rr->identification = htons(++counter);

		udp->uh_sum = 0;
		udp->uh_sum = click_in_cksum((const unsigned char *) udp, sizeof(click_udp) + sizeof(RegistrationRequestData));

		output(0).push(packet);

		_lastRequest = time(0);
	}
}

void RegistrationRequest::run_timer(Timer * timer)
{
	if (_currentAgent == 0)
		click_chatter("Mobile Node -- Looking for an agent, trying to connect with it.");
	else
	{
		click_chatter("Mobile Node -- Lost connection to my current agent, trying to reconnect.");
	}

	HandlerCall::call_write("solicit", (Element *) _sol, new ErrorHandler());
}

void RegistrationRequest::reRegister()
{
	click_chatter("Mobile Node -- Registration timed out, re-registrating...");

	_registrated = false;

	if (_lastP != 0)
	{
		generateRequest(_lastP);

		reregister.clear();
		reregister.schedule_after_msec(_lifetime * 1000 - 500);
	}
}

void RegistrationRequest::lifetime(int lifetime)
{
	if (_lastP)
	{
		bool isHomeAgent = IPAddress(_lastP->ip_header()->ip_src).matches_prefix(_me, IPAddress::make_prefix(24));

		if (!isHomeAgent && lifetime != 0)
		{
			if (lifetime != _lifetime)
			{
				if (lifetime > _lifetime)
					lifetime = _lifetime;

				// As our lifetime was changed, we must start counting again!
				reregister.clear();
				reregister.schedule_after_msec(lifetime * 1000 - 500);
			}

			_registrated = true;

			click_chatter("Mobile Node -- Registration succesful!");
		}
		else
		{
			_registrated = false;

			click_chatter("Mobile Node -- Deregistration succesful!");
		}
	}
}

int doLifetime(const String & data, Element * element, void * user_data, ErrorHandler * error)
{
	((RegistrationRequest *) element)->lifetime(atoi(data.c_str()));
}

void RegistrationRequest::add_handlers()
{
	int data = 0;
	add_write_handler("lifetime", doLifetime, data, 0);
}

void RegistrationRequest::push(int, Packet *p)
{
	if (isMobileNode)
	{
		ICMPRouterAdvertisement * ira = (ICMPRouterAdvertisement *) (p	->data() + sizeof(click_ip) + sizeof(click_icmp_echo) / 2);

		if (_currentAgent == 0 || _currentAgent->hashcode() != IPAddress(p->ip_header()->ip_src).hashcode())
		{
			if (_currentAgent == 0)
				click_chatter("Mobile Node -- Connected to an agent, registrating...");
			else
			{
				click_chatter("Mobile Node -- Found a different agent, (de)registrating...");
			}

			if (_currentAgent != 0)
				delete _currentAgent;

			_currentAgent = new IPAddress(p->ip_header()->ip_src);

			if (_lastP != 0)
				_lastP->kill();

			_lastP = 0;
		}

		timer.clear();
		timer.schedule_after_msec(ntohs(ira->lifetime) * 1000);

		int sequenceNumber = ((click_icmp_echo *) p->data() + sizeof(click_ip))->icmp_sequence;

		if ((sequenceNumber < _lastSequenceNumber && sequenceNumber < 255) || _lastP == 0)
		{
			_registrated = false;

			generateRequest(p);

			_lastP = p;
		}

		_lastSequenceNumber = sequenceNumber;
	}
	else
	{
		forward(p);
		p->kill();
	}
}

CLICK_ENDDECLS
EXPORT_ELEMENT(RegistrationRequest)
