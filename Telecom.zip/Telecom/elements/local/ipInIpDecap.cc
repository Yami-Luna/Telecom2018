#include <click/config.h>
#include <click/confparse.hh>
#include <click/error.hh>
#include <click/ipaddress.hh>
#include <clicknet/ip.h>
#include <clicknet/icmp.h>
#include "ipInIpDecap.hh"
#include "ipHeader.hh"

CLICK_DECLS

IpInIpDecap::IpInIpDecap() {}

IpInIpDecap::~IpInIpDecap() {}

int IpInIpDecap::configure(Vector<String> &conf, ErrorHandler *errh) {
	if (cp_va_kparse(conf, this, errh, cpEnd) < 0) return -1;
	return 0;
}

void IpInIpDecap::push(int, Packet *p){
	// Avoid other packets than the router solicitation.
	if (!p->has_network_header() || p->ip_header()->ip_p != 4) return;

	int offset = 0;
	int tailroom = 0;
	int headroom = sizeof(click_ip);
	int packetsize = headroom + (int) (p->length()) - 2 * sizeof(click_ip);
	WritablePacket * packet = Packet::make(headroom, 0, packetsize, tailroom);

	if (packet == 0) {
		click_chatter( "Cannot make packet");

		return;
	}

	memset(packet->data(), 0, packetsize);
	memcpy(packet->data(), p->data() + sizeof(click_ip), packetsize);

	click_ip * ip = (click_ip *) (packet->data());
	packet->set_dst_ip_anno(ip->ip_dst);
	checksumIPHeader(ip);
	packet->set_network_header((unsigned char *) ip, sizeof(click_ip));

	output(0).push(packet);
}

CLICK_ENDDECLS
ELEMENT_REQUIRES(IPHeader)
EXPORT_ELEMENT(IpInIpDecap)

