#include <click/config.h>
#include <click/confparse.hh>
#include <click/error.hh>
#include <click/ipaddress.hh>
#include <clicknet/ip.h>
#include <clicknet/icmp.h>
#include "solicitation.hh"
#include "ipHeader.hh"

CLICK_DECLS

Solicitation::Solicitation() : counter(0) {}

Solicitation::~Solicitation() {}

int Solicitation::configure(Vector<String> &conf, ErrorHandler *errh)
{
	bool timerEnabled;

	if (cp_va_kparse(conf, this, errh,	"SRC", cpkM, cpIPAddress, &_srcIP,
										"DST", cpkM, cpIPAddress, &_dstIP,
										cpEnd) < 0) return -1;

	return 0;
}

void Solicitation::solicit()
{
	click_chatter("Mobile Node -- Sending solicitation.");
	int offset = 0;
	int tailroom = 0;
	int headroom = sizeof(click_ip);
	int packetsize = headroom + sizeof(click_icmp_echo);
	WritablePacket * packet = Packet::make(headroom, 0, packetsize, tailroom);

	if (packet == 0) {
		click_chatter( "Cannot make packet");

		packet->kill();
		return;
	}

	memset(packet->data(), 0, packetsize);

	click_ip * ip = initIPHeader(packet, (click_ip *) (packet->data() + offset), packetsize, 1, counter, 1, _srcIP, _dstIP);
	offset += sizeof(click_ip);
	packet->set_network_header((unsigned char *) ip, sizeof(click_ip));

	click_icmp_echo * icmp = (click_icmp_echo *) (packet->data() + offset);
	icmp->icmp_type = 10;
	icmp->icmp_code = 0;
	icmp->icmp_identifier = 0;
	icmp->icmp_sequence = htons(++counter);
	icmp->icmp_cksum = click_in_cksum((const unsigned char *) icmp, sizeof(click_icmp_echo));

	output(0).push(packet);
}

int doSolicit(const String & data, Element * element, void * user_data, ErrorHandler * error)
{
	((Solicitation *) element)->solicit();
}

void Solicitation::add_handlers()
{
	int data;
	add_write_handler("solicit", doSolicit, data, 0);
}

CLICK_ENDDECLS
EXPORT_ELEMENT(Solicitation)

