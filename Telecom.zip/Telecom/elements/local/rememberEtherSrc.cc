#include <click/config.h>
#include <click/confparse.hh>
#include <click/error.hh>
#include <clicknet/ether.h>
#include "rememberEtherSrc.hh"

CLICK_DECLS

RememberEtherSrc::RememberEtherSrc() : seh(0) {}

RememberEtherSrc::~RememberEtherSrc() {}

int RememberEtherSrc::configure(Vector<String> &conf, ErrorHandler *errh) {
	if (cp_va_kparse(conf, this, errh, cpEnd) < 0) return -1;
	return 0;
}

void RememberEtherSrc::push(int port, Packet *p){
	// Rewrite the Ethernet destination.
	if (port == 1)
	{
		WritablePacket * packet = p->uniqueify();

		click_ether * deh = (click_ether *) packet->data();
		if (seh != 0)
			memcpy(deh->ether_dhost, seh->ether_shost, 6);

		output(0).push(packet);
	}
	// Remember the Ethernet source.
	else
	{
		seh = new click_ether();
		memcpy(seh, (click_ether *) p->data(), sizeof(click_ether));
	}

	p->kill();
}

CLICK_ENDDECLS
EXPORT_ELEMENT(RememberEtherSrc)
