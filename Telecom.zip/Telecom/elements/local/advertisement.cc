#include <click/config.h>
#include <click/confparse.hh>
#include <click/error.hh>
#include <click/ipaddress.hh>
#include <clicknet/ip.h>
#include <clicknet/icmp.h>
#include "advertisement.hh"
#include "ipHeader.hh"

CLICK_DECLS

Advertisement::Advertisement() : timer(this), counter(0) { }

Advertisement::~Advertisement() {}

int Advertisement::configure(Vector<String> &conf, ErrorHandler *errh) {
	bool timerEnabled;

	if (cp_va_kparse(conf, this, errh, 	"SRC", cpkM, cpIPAddress, &_srcIP,
										"COA", cpkN, cpIPAddress, &_coaIP,
										"ISHOME", cpkM, cpBool, &isHomeAgent,
										"TIMER", cpkM, cpBool, &timerEnabled,
										"LIFETIME", cpkM, cpInteger, &_lifetime,
										"REGLIFETIME", cpkM, cpInteger, &_regLifetime,
										cpEnd) < 0) return -1;

	if (timerEnabled)
	{
		timer.initialize(this);
		timer.schedule_after_msec(0);
	}

	// TODO: Check for a FA whether an IP address was provided.
	// TODO: Check the amount of input ports, there shouldn't be an input if the timer is enabled so EtherEncap can be used.

	return 0;
}

void Advertisement::run_timer(Timer* t) {
	timer.schedule_after_msec(900 + 200 * (rand() / RAND_MAX));
	
	push_packet(0, true);
}

void Advertisement::push_packet(Packet * p, bool broadcast = false) {
	if (isHomeAgent)
		click_chatter("Home Agent -- Sending advertisement.");
	else
		click_chatter("Foreign Agent -- Sending advertisement.");

	int offset = 0;
	int tailroom = 0;
	int headroom = sizeof(click_ip);
	int packetsize = headroom + sizeof(click_icmp_echo) / 2 + sizeof(ICMPRouterAdvertisement) + sizeof(MobileAgentAdvertisement);
	if (!isHomeAgent)
		packetsize += sizeof(IPAddress);
	WritablePacket * packet = Packet::make(headroom, 0, packetsize, tailroom);

	if (packet == 0) {
		click_chatter( "Cannot make packet");

		p->kill();

		return;
	}

	memset(packet->data(), 0, packetsize);

	click_ip * ip;

	if (broadcast)
		ip = initIPHeader(packet, (click_ip *) (packet->data() + offset), packetsize, 1, counter, 1, _srcIP, IPAddress("255.255.255.255"));
	else
		ip = initIPHeader(packet, (click_ip *) (packet->data() + offset), packetsize, 1, counter, 1, _srcIP, p->ip_header()->ip_src);
	offset += sizeof(click_ip);
	packet->set_network_header((unsigned char *) ip, sizeof(click_ip));

	click_icmp_echo * icmp = (click_icmp_echo *) (packet->data() + offset);
	icmp->icmp_type = 9;
	icmp->icmp_code = 0;
	icmp->icmp_identifier = 0;
	icmp->icmp_sequence = htons(counter);
	if (counter == 0xffff)
		counter = 256;
	else
		++counter;
	offset += sizeof(click_icmp_echo) / 2;

	ICMPRouterAdvertisement * ira = (ICMPRouterAdvertisement *) (packet->data() + sizeof(click_ip) + sizeof(click_icmp_echo) / 2);
	ira->num_addr = 1;
	ira->address_entry_size = 2;
	ira->lifetime = htons(_lifetime);
	memcpy(&ira->router_address, &_srcIP, sizeof(IPAddress));
	ira->preference = 0x00000001;
	offset += sizeof(ICMPRouterAdvertisement);

	MobileAgentAdvertisement * maa = (MobileAgentAdvertisement *) (packet->data() + offset);
	maa->type = 16;
	maa->length = 6;
	maa->seq_nr = htons(counter);
	maa->lifetime = htons(_regLifetime);

	if (isHomeAgent) {
		maa->flags = (1 << 5);
		icmp->icmp_cksum = 0;
		icmp->icmp_cksum = click_in_cksum((const unsigned char *) icmp, sizeof(click_icmp_echo) / 2 + sizeof(ICMPRouterAdvertisement) + sizeof(MobileAgentAdvertisement));
	} else {
		maa->length += 4;
		maa->flags = (1 << 4) | (1 << 7);
		offset += sizeof(MobileAgentAdvertisement);
		IPAddress * ipAddress = (IPAddress *) (packet->data() + offset);
		memcpy(ipAddress, &_coaIP, sizeof(IPAddress));
		icmp->icmp_cksum = 0;
		icmp->icmp_cksum = click_in_cksum((const unsigned char *) icmp, sizeof(click_icmp_echo) / 2 + sizeof(ICMPRouterAdvertisement) + sizeof(MobileAgentAdvertisement) + sizeof(IPAddress));
	}

	output(0).push(packet);

	if (!broadcast)
		p->kill();
}

void Advertisement::push(int, Packet *p) {
	push_packet(p);
}

CLICK_ENDDECLS
ELEMENT_REQUIRES(IPHeader)
EXPORT_ELEMENT(Advertisement)
