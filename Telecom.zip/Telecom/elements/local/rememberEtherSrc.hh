#ifndef CLICK_REMEMBERETHERSRC_HH
#define CLICK_REMEMBERETHERSRC_HH

#include <click/element.hh>

CLICK_DECLS

class RememberEtherSrc : public Element {
private:
	click_ether * seh;
public:
	RememberEtherSrc();
	~RememberEtherSrc();

	const char *class_name() const	{ return "RememberEtherSrc"; }
	const char *port_count() const	{ return "2/1"; }
	const char *processing() const	{ return PUSH; }
	int configure(Vector<String> &, ErrorHandler *);

	void push(int, Packet *);
};

CLICK_ENDDECLS

#endif
